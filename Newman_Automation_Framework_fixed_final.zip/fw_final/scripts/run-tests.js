// ======================================================
// scripts/run-tests.js
// ======================================================
//
// FLOW:
//   1. Read framework.properties
//   2. Load live-collection.json from collectionOutputPath
//      → Run download-collection.js first if file is missing
//   3. Run target folder from live collection
//      → HTML report, evidence (docx or txt)
//      → update CSV/Excel data file
//      → optionally copy data file to report folder
//
// To refresh the collection from Postman at any time:
//   node download-collection.js
//
// ======================================================

const fs     = require('fs');
const path   = require('path');
const Papa   = require('papaparse');
const newman = require('newman');
const XLSX   = require('xlsx');
const yaml   = require('js-yaml');

const readProperties       = require('./properties-reader');
const generateWordReport   = require('./generate-word-report');
const generateTextReport   = require('./generate-text-report');
const generateExtentReport = require('./generate-extent-report');
const swaggerValidator     = require('./swagger-validator');

const {
    getValueFromPath,
    getFileConfig,
    sanitizeRow
} = require('./utils');

// ======================================================
// LOAD FRAMEWORK CONFIG
// ======================================================

const framework =
    readProperties('./config/framework.properties');

// ── new config values ──────────────────────────────────

const evidenceFormat =
    (framework.evidenceFormat || 'docx')
        .toLowerCase()
        .trim();

const copyTestDataToReports =
    (framework.copyTestDataToReports || 'true')
        .toLowerCase()
        .trim() === 'true';

const testCaseNameColumn =
    (framework.testCaseNameColumn || 'testCaseName')
        .trim();

const testScenarioTypeColumn =
    (framework.testScenarioTypeColumn || '')
        .trim();

console.log('\n📋 Framework Configuration');
console.log(`   Evidence Format:          ${evidenceFormat.toUpperCase()}`);
console.log(`   Copy Test Data:           ${copyTestDataToReports}`);
console.log(`   Test Case Name Column:    ${testCaseNameColumn}`);
console.log(`   Scenario Type Column:     ${testScenarioTypeColumn || '(not set)'}`);

// ======================================================
// INPUTS FROM runner.js
// ======================================================

const targetFolder =
    process.argv[2];

const iterationCount =
    process.argv[3];

// ======================================================
// COLLECTION OUTPUT PATH
// ======================================================

const collectionOutputPath =
    framework.collectionOutputPath ||
    './collection/live-collection.json';

// ======================================================
// LOAD MAPPING FILES
// ======================================================

const isYaml =
    framework.mappingType === 'yaml';

// ── API field mapping (csv_update) ─────────────────────

let apiFieldMapping = {};

try {

    apiFieldMapping = isYaml
        ? yaml.load(
            fs.readFileSync('./config/csv_update.yaml', 'utf8')
          )
        : JSON.parse(
            fs.readFileSync('./config/csv_update.json', 'utf8')
          );

} catch {

    console.log(
        'ℹ️  No API field mapping found (csv_update) — skipping field extraction'
    );
}

// ── folder mapping ─────────────────────────────────────

let folderCsvMap = {};

try {

    folderCsvMap = isYaml
        ? yaml.load(
            fs.readFileSync('./config/folderMapping.yaml', 'utf8')
          )
        : JSON.parse(
            fs.readFileSync('./config/folderMapping.json', 'utf8')
          );

} catch {

    console.log(
        'ℹ️  No folder mapping found — running without data file'
    );
}

// ======================================================
// LOAD SWAGGER MAPPING
// ======================================================
//
// config/swagger_mapping.yaml (or .json) maps API request
// names and folder names → spec filenames in ./swagger/.
// If the file is missing the feature is silently disabled.
//
// Structure:
//   Create_User:            ← matches Postman request name
//     spec: banking-api.yaml
//   Payments:               ← matches Postman folder name
//     spec: payments-api.yaml
//
// API-level mapping takes priority over folder-level.
// ======================================================

let swaggerMapping = {};

try {
    const swMappingPath = isYaml
        ? './config/swagger_mapping.yaml'
        : './config/swagger_mapping.json';

    if (fs.existsSync(swMappingPath)) {
        swaggerMapping = isYaml
            ? yaml.load(fs.readFileSync(swMappingPath, 'utf8'))
            : JSON.parse(fs.readFileSync(swMappingPath, 'utf8'));

        // Remove comment keys (JSON _comment etc.)
        Object.keys(swaggerMapping).forEach(k => {
            if (k.startsWith('_')) delete swaggerMapping[k];
        });

        console.log(
            `📋 Swagger mapping loaded: ${Object.keys(swaggerMapping).length} entries`
        );
    } else {
        console.log('ℹ️  No swagger_mapping file found — Swagger compliance assertions disabled');
    }
} catch (e) {
    console.log(`⚠️  Swagger mapping load error: ${e.message}`);
}

// Pre-load all unique spec files referenced in the mapping
// (avoids re-parsing the same file for every request)
const _loadedSpecs = {};
Object.values(swaggerMapping).forEach(entry => {
    if (entry && entry.spec && !_loadedSpecs[entry.spec]) {
        _loadedSpecs[entry.spec] = swaggerValidator.loadSpec(entry.spec);
    }
});

/**
 * Returns the loaded spec for a given API request + folder,
 * or null if no mapping exists.
 * API-level mapping takes priority over folder-level.
 */
function getSpecForApi(apiName, folderName) {
    const apiEntry    = swaggerMapping[apiName];
    const folderEntry = swaggerMapping[folderName] || swaggerMapping[targetFolder || 'ROOT'];
    const entry       = apiEntry || folderEntry || null;
    if (!entry || !entry.spec) return null;
    return _loadedSpecs[entry.spec] || null;
}

// ======================================================
// REPORT FOLDER
// ======================================================

const timestamp =
    new Date()
        .toISOString()
        .replace(/[:.]/g, '-');

const reportFolder =
    `./reports/${targetFolder || 'ROOT'}_${timestamp}`;

// evidence folder removed — individual txt files not generated

// ======================================================
// GET INPUT FILE FOR TARGET FOLDER
// ======================================================

let currentFolderConfig = null;

if (targetFolder && folderCsvMap[targetFolder]) {

    currentFolderConfig =
        getFileConfig(folderCsvMap, targetFolder);

} else if (folderCsvMap['ROOT']) {

    currentFolderConfig =
        getFileConfig(folderCsvMap, 'ROOT');
}

const inputFile =
    currentFolderConfig?.file || null;

// ======================================================
// READ EXCEL DATA → array of row objects
// ======================================================

function readExcelData(excelPath, worksheetName) {

    const workbook =
        XLSX.readFile(excelPath, { cellDates: true });

    if (
        !worksheetName ||
        !workbook.SheetNames.includes(worksheetName)
    ) {
        worksheetName = workbook.SheetNames[0];
        console.log(`📄 Using first worksheet: ${worksheetName}`);
    } else {
        console.log(`📄 Using worksheet: ${worksheetName}`);
    }

    const worksheet =
        workbook.Sheets[worksheetName];

    // raw: true  → dates come back as JS Date objects, booleans as true/false
    // defval: '' → missing cells become empty string (not undefined)
    const rawRows =
        XLSX.utils.sheet_to_json(
            worksheet,
            { defval: '', raw: true }
        );

    // Normalise every row: yyyy-mm-dd dates, lowercase booleans.
    // Invalid date strings are passed through unchanged so that
    // negative-scenario rows still reach the API as-is.
    return rawRows.map(row => sanitizeRow(row));
}

// ======================================================
// SSL OPTIONS
// ======================================================

const sslOptions = {
    enabled:    framework.sslEnabled === 'true',
    cert:       framework.sslEnabled === 'true'
                    ? fs.readFileSync(framework.sslCert)
                    : null,
    key:        framework.sslEnabled === 'true'
                    ? fs.readFileSync(framework.sslKey)
                    : null,
    passphrase: framework.sslPassphrase
};

// ======================================================
// STORES
// ======================================================

// iterationApiStore[i] = [ { apiName, statusCode, requestBody, responseBody, result } ]
const iterationApiStore = {};

// responseStore[storeKey][i][apiName] = { col: value, ... }
// Each API in the folder gets its own slot so multi-API folders
// don't overwrite each other's request/response/status data.
const responseStore = {};

// resultStore[storeKey][i] = 'PASSED' | 'FAILED'
const resultStore = {};

// Raw data rows for test case name lookup
let iterationDataRows = [];

// ======================================================
// BUILD FLAT EXECUTION SEQUENCE
// (walks the loaded collection tree in the SAME order
//  Newman executes requests)
//
// Returns an array of { folder, name } in execution order.
// This is collision-proof for duplicate API names because
// we match executions by POSITION (cursor.position / a
// running counter), not by name.
//
// If `onlyFolder` is given, only items under that folder
// are included (matches newmanOptions.folder behaviour) —
// all entries get folder = onlyFolder.
// ======================================================

function buildExecutionSequence(
    items,
    currentFolder = null,
    onlyFolder = null,
    sequence = [],
    insideTarget = !onlyFolder
) {

    if (!Array.isArray(items)) return sequence;

    items.forEach(item => {

        if (item.item) {

            const isThisTheTargetFolder =
                onlyFolder && item.name === onlyFolder;

            buildExecutionSequence(
                item.item,
                item.name,
                onlyFolder,
                sequence,
                insideTarget || isThisTheTargetFolder
            );

        } else if (insideTarget) {

            sequence.push({
                folder: currentFolder || 'ROOT',
                name:   item.name
            });
        }
    });

    return sequence;
}

/**
 * Resolves { folder, apiKey } for a Newman execution/request
 * event using its position in the run (cursor.position),
 * indexed into the pre-built executionSequence.
 *
 * Falls back to the request's own name/folder guess if the
 * position is out of range (shouldn't normally happen).
 */
function resolveByPosition(position, requestName, executionSequence) {

    const entry = executionSequence[position];

    if (entry) {
        return {
            folder: entry.folder,
            apiKey: `${entry.folder}::${requestName}`
        };
    }

    return {
        folder: 'ROOT',
        apiKey: `ROOT::${requestName}`
    };
}

// ======================================================
// MAIN
// ======================================================


async function main() {

    // ── 0. ensure report folder exists ─────────────────
    //
    // Newman's html reporter creates this as a side-effect,
    // but evidence/extent reports are written independently
    // and must not depend on that ordering.

    fs.mkdirSync(reportFolder, { recursive: true });

    // ── 1. load live-collection.json ───────────────────
    //
    // Run  node download-collection.js  first if you
    // need to pull the latest version from Postman.

    if (!fs.existsSync(path.resolve(collectionOutputPath))) {
        console.log(
            `\n❌  Collection file not found: ${collectionOutputPath}` +
            `\n    Run this first to download it from Postman:` +
            `\n    node download-collection.js\n`
        );
        process.exit(1);
    }

    let liveCollection;

    try {

        const raw =
            fs.readFileSync(
                path.resolve(collectionOutputPath),
                'utf8'
            );

        liveCollection = JSON.parse(raw);

    } catch (err) {
        console.log(
            `❌  Failed to load collection from: ${collectionOutputPath}\n` +
            `    ${err.message}\n` +
            `    Run: node download-collection.js`
        );
        process.exit(1);
    }

    console.log(
        `\n📦 Collection loaded: "${liveCollection.info?.name || collectionOutputPath}"` +
        `\n🚀 Starting test run: ${targetFolder || 'ROOT'}`
    );

    // ── 4. build flat execution-order sequence ─────────
    // (collision-proof folder resolution by position)

    const executionSequence =
        buildExecutionSequence(
            liveCollection.item,
            null,
            targetFolder || null
        );

    // ── 5. build newman options ────────────────────────

    const newmanOptions = {

        collection: liveCollection,

        reporters: ['cli', 'htmlextra'],

        reporter: {
            htmlextra: {
                export:           `${reportFolder}/report.html`,
                title:            `${targetFolder || 'ROOT'} Report`,
                showIterationData: true,
                logs:              true,
                browserTitle:      'Automation Report'
            }
        },

        timeout:        0,
        timeoutRequest: 0,
        timeoutScript:  0
    };

    // iteration count
    if (
        iterationCount !== undefined &&
        iterationCount !== null &&
        iterationCount !== '' &&
        !isNaN(iterationCount)
    ) {
        newmanOptions.iterationCount =
            Number(iterationCount);

        console.log(
            `🔁 Running ${iterationCount} iterations`
        );

    } else {

        console.log('🔁 Running ALL iterations');
    }

    // folder filter
    if (targetFolder) {
        newmanOptions.folder = targetFolder;
    }

    // data file
    if (inputFile) {

        if (inputFile.endsWith('.xlsx')) {

            const rows =
                readExcelData(
                    inputFile,
                    currentFolderConfig?.worksheet
                );

            iterationDataRows = rows;
            newmanOptions.iterationData = rows;

            console.log(`📘 Using Excel File: ${inputFile}`);

        } else {

            // CSV — pre-read rows so we can look up testCaseName
            try {
                const csvContent =
                    fs.readFileSync(inputFile, 'utf8');

                const parsed =
                    Papa.parse(csvContent, {
                        header: true,
                        skipEmptyLines: true
                    });

                iterationDataRows = parsed.data.map(row => sanitizeRow(row));

            } catch {
                iterationDataRows = [];
            }

            newmanOptions.iterationData = iterationDataRows;

            console.log(`📄 Using CSV File: ${inputFile}`);
        }

    } else {

        console.log('ℹ️  Running without data file');
    }

    // SSL
    if (sslOptions.enabled) {

        console.log('🔐 SSL Enabled');

        newmanOptions.sslClientCert =
            sslOptions.cert;

        newmanOptions.sslClientKey =
            sslOptions.key;

        newmanOptions.sslClientPassphrase =
            sslOptions.passphrase;
    }

    // ── 6. run newman ──────────────────────────────────

    const runStartTime = new Date();

    newman.run(newmanOptions)

    // ── REQUEST EVENT ──────────────────────────────────

    .on('request', (err, args) => {

        if (err) return;

        const requestName =
            args.item.name;

        const iteration =
            args.cursor.iteration;

        const position =
            args.cursor.position;

        // Resolve folder + unique apiKey by execution position —
        // collision-proof even when two folders (or the same
        // folder) contain requests with identical names.
        const { folder: folderName, apiKey } =
            resolveByPosition(position, requestName, executionSequence);

        // skip requests outside the target folder
        if (
            targetFolder &&
            folderName !== targetFolder &&
            requestName !== targetFolder
        ) {
            return;
        }


        const requestBody =
            args.request.body?.raw || '';

        const responseBody =
            args.response.stream.toString();

        const statusCode =
            args.response.code;

        // ── console output ─────────────────────────────

        console.log('\n================================');
        console.log(`API:         ${requestName}`);
        console.log(`Iteration:   ${iteration}`);
        console.log(`Status Code: ${statusCode}`);
        console.log('\nREQUEST BODY:\n');
        console.log(requestBody);
        console.log('\nRESPONSE BODY:\n');
        console.log(responseBody);
        console.log('\n================================');

        // ── swagger compliance check ───────────────────
        // Look up spec by API name first, then folder name.
        // If no mapping exists, swaggerResult is a neutral pass
        // and NO swagger assertion is added to the report.

        const _swSpec = getSpecForApi(requestName, folderName);

        let swaggerResult = null; // null = no mapping, assertion omitted

        if (_swSpec) {

            const _resHeaders = {};
            (args.response.headers?.members || []).forEach(m => {
                if (m.key) _resHeaders[m.key] = m.value || '';
            });

            swaggerResult = swaggerValidator.validateResponse(
                _swSpec,
                args.request.method || 'GET',
                args.request.url?.toString() || '',
                statusCode,
                responseBody,
                _resHeaders
            );

            if (!swaggerResult.passed) {
                console.log(
                    `⚠️  Swagger violations [${requestName}] ` +
                    `(${swaggerResult.violations.length}):`
                );
                swaggerResult.violations.forEach(v =>
                    console.log(`   [${v.code}] ${v.message}`)
                );
            }
        }

        // ── collect for report ─────────────────────────

        if (!iterationApiStore[iteration]) {
            iterationApiStore[iteration] = [];
        }

        iterationApiStore[iteration].push({
            apiKey:          apiKey,          // unique: "Folder::Name"
            apiName:         requestName,     // display name (original)
            folderName:      folderName,      // parent folder
            method:          args.request.method || 'GET',
            url:             args.request.url?.toString() || '',
            statusCode:      statusCode,
            requestBody:     requestBody,
            responseBody:    responseBody,
            requestHeaders:  (() => {
                const h = {};
                (args.request.headers?.members || []).forEach(m => {
                    if (m.key) h[m.key] = m.value || '';
                });
                return h;
            })(),
            responseHeaders: (() => {
                const h = {};
                (args.response.headers?.members || []).forEach(m => {
                    if (m.key) h[m.key] = m.value || '';
                });
                return h;
            })(),
            responseTime:    args.response.responseTime || 0,
            swaggerResult:   swaggerResult,   // null = no mapping; object = validated
            result:          null,   // filled in 'done'
            assertions:      []      // filled in 'done'
        });

        // ── response field extraction ──────────────────

        const storeKey =
            targetFolder === requestName
                ? targetFolder
                : folderName;

        if (!responseStore[storeKey]) {
            responseStore[storeKey] = [];
        }

        // Store per-API so multiple APIs in the same folder
        // don't overwrite each other's data in the same iteration.
        if (!responseStore[storeKey][iteration][requestName]) {
            responseStore[storeKey][iteration][requestName] = {};
        }

        const apiSlot = responseStore[storeKey][iteration][requestName];
        apiSlot.requestBody         = requestBody;
        apiSlot.responseBody        = responseBody;
        apiSlot.responseStatusCode  = statusCode;

        try {

            const res = JSON.parse(responseBody);

            const mapping =
                apiFieldMapping[requestName];

            if (mapping && mapping !== null) {

                Object.keys(mapping).forEach(col => {

                    apiSlot[col] =
                        getValueFromPath(res, mapping[col]);
                });
            }

        } catch {

            console.log(
                `⚠️  Non-JSON response for: ${requestName}`
            );
        }
    })

    // ── DONE EVENT ─────────────────────────────────────

    .on('done', async (err, summary) => {

        if (err) {
            console.log(err);
            process.exit(1);
        }

        // ── collect pass/fail per API per iteration ────

        summary.run.executions.forEach((exec) => {

            const requestName =
                exec.item.name;

            const i =
                exec.cursor.iteration;

            // cursor.position is the per-iteration index of this
            // request — matches the index into executionSequence
            // (which represents one iteration's worth of requests
            // in collection order).
            const cursorPosition = exec.cursor.position;

            const { folder: folderName, apiKey } =
                resolveByPosition(cursorPosition, requestName, executionSequence);

            if (
                targetFolder &&
                folderName !== targetFolder &&
                requestName !== targetFolder
            ) {
                return;
            }

            const passed =
                exec.assertions?.every(a => !a.error) ?? true;

            const result =
                passed ? 'PASSED' : 'FAILED';

            // mark result + assertions in iterationApiStore
            // Match by apiKey (collision-proof) — fallback to
            // first unresolved entry with the same name + iteration.
            if (iterationApiStore[i]) {

                const apiEntry =
                    iterationApiStore[i].find(
                        a => a.apiKey === apiKey
                    ) ||
                    iterationApiStore[i].find(
                        a => a.apiName === requestName && a.result === null
                    );

                if (apiEntry) {

                    // Standard Newman test assertions
                    const newmanAssertions =
                        (exec.assertions || []).map(a => ({
                            name:   a.assertion || '',
                            passed: !a.error,
                            error:  a.error ? a.error.message || String(a.error) : null,
                            type:   'newman'
                        }));

                    // Swagger compliance assertions — only added when a
                    // mapping exists for this API or its parent folder.
                    // If no mapping → swaggerResult is null → no assertion.
                    const swaggerAssertions = [];

                    if (apiEntry.swaggerResult !== null) {

                        const sr = apiEntry.swaggerResult;

                        if (sr.passed) {
                            // Single green compliance tick
                            swaggerAssertions.push({
                                name:   '[Swagger] Response is compliant with OpenAPI spec',
                                passed: true,
                                error:  null,
                                type:   'swagger'
                            });
                        } else {
                            // One assertion row per violation
                            sr.violations.forEach(v => {
                                swaggerAssertions.push({
                                    name:   `[Swagger] ${v.code}: ${v.message}`,
                                    passed: false,
                                    error:  v.message,
                                    type:   'swagger'
                                });
                            });
                        }
                    }

                    apiEntry.assertions = [
                        ...newmanAssertions,
                        ...swaggerAssertions
                    ];

                    // Swagger violations count as FAILED
                    const swaggerFailed =
                        swaggerAssertions.some(a => !a.passed);

                    apiEntry.result =
                        (result === 'FAILED' || swaggerFailed)
                            ? 'FAILED'
                            : 'PASSED';
                }
            }

            // result store for CSV/Excel update
            const storeKey =
                targetFolder === requestName
                    ? targetFolder
                    : folderName;

            if (!resultStore[storeKey]) {
                resultStore[storeKey] = [];
            }

            resultStore[storeKey][i] = result;
        });

        // ── assemble evidence data ─────────────────────

        const evidenceData = [];

        const iterations =
            Object.keys(iterationApiStore)
                .map(Number)
                .sort((a, b) => a - b);

        iterations.forEach(iter => {

            const testCaseName =
                iterationDataRows[iter]
                    ? (
                        iterationDataRows[iter][testCaseNameColumn] ||
                        `Iteration ${iter}`
                      )
                    : `Iteration ${iter}`;

            const scenarioType =
                testScenarioTypeColumn && iterationDataRows[iter]
                    ? (iterationDataRows[iter][testScenarioTypeColumn] || '')
                    : '';

            // Filter out APIs whose result was never set in the done event.
            // These are ghost entries from pre/post hooks or out-of-scope
            // requests captured by the request event but not in executions.
            const apis =
                iterationApiStore[iter]
                    .filter(api => api.result !== null)
                    .map(api => ({
                        ...api,
                        result: api.result || 'UNKNOWN'
                    }));

            evidenceData.push({
                iteration:    iter,
                testCaseName,
                scenarioType,
                apis
            });
        });

        // ── generate evidence report ───────────────────

        if (evidenceData.length > 0) {

            if (evidenceFormat === 'txt') {

                generateTextReport(
                    reportFolder,
                    evidenceData
                );

            } else {

                try {

                    await generateWordReport(
                        reportFolder,
                        evidenceData
                    );

                } catch (docxErr) {

                    console.log(
                        `⚠️  Word report failed: ${docxErr.message}`
                    );
                    console.log(
                        '   Falling back to text report…'
                    );

                    generateTextReport(
                        reportFolder,
                        evidenceData
                    );
                }
            }

        } else {

            console.log('⚠️  No evidence data collected');
        }

        // ── update data file ───────────────────────────

        if (currentFolderConfig && inputFile) {

            const storeKey =
                targetFolder || 'ROOT';

            try {
                await updateDataFile(
                    inputFile,
                    responseStore[storeKey] || [],
                    resultStore[storeKey]   || [],
                    currentFolderConfig
                );
            } catch (updateErr) {
                console.log(
                    `⚠️  Data file update error: ${updateErr.message}`
                );
                console.log(
                    '   Continuing to generate extent report...'
                );
            }
        }

        // ── generate extent report ────────────────────

        const runEndTime = new Date();

        // Resolve attachment paths for Summary page.
        // Both files must be looked up inside reportFolder:
        //   - data file: copied there by updateDataFile() above
        //   - evidence file: written there by generateWordReport/generateTextReport above

        // Data file — find the copied version in reportFolder
        let summaryDataFile = null;
        try {
            const rfiles = fs.readdirSync(reportFolder);
            const df = rfiles.find(f => f.endsWith('.csv') || f.endsWith('.xlsx'));
            if (df) summaryDataFile = path.join(reportFolder, df);
        } catch {}

        // Fall back to original input file if copy not found
        if (!summaryDataFile && inputFile) {
            summaryDataFile = path.resolve(inputFile);
        }

        // Evidence file — written by generateWordReport/generateTextReport above
        let summaryEvidenceFile = null;
        try {
            const rfiles = fs.readdirSync(reportFolder);
            const ef = rfiles.find(f => f === 'ExecutionEvidence.docx' || f === 'ExecutionEvidence.txt');
            if (ef) summaryEvidenceFile = path.join(reportFolder, ef);
        } catch {}

        let extentGenerated = false;

        try {
            generateExtentReport(
                reportFolder,
                evidenceData,
                {
                    collectionName:  liveCollection.info?.name || 'Newman Tests',
                    folderName:      targetFolder || 'ROOT',
                    startTime:       runStartTime,
                    endTime:         runEndTime,
                    totalDuration:   runEndTime - runStartTime,
                    dataFilePath:    summaryDataFile,
                    evidenceFile:    summaryEvidenceFile,
                    evidenceFormat:  evidenceFormat
                }
            );

            extentGenerated =
                fs.existsSync(path.join(reportFolder, 'extent-report.html'));

        } catch (extentErr) {
            console.log(`❌ Extent report generation failed: ${extentErr.message}`);
            console.log(extentErr.stack);
        }

        console.log('\n🎉 Execution Completed');

        if (extentGenerated) {
            console.log(`📁 Extent Report:  ${reportFolder}/extent-report.html`);
        } else {
            console.log(`⚠️  Extent Report was NOT generated in: ${reportFolder}`);
        }

        console.log(`📁 HTML Report:    ${reportFolder}/report.html`);
    });
}


// ======================================================
// FLATTEN PER-API RESPONSE DATA INTO ROW COLUMNS
// ======================================================
//
// responseData[i] is now { apiName: { col: val, ... }, ... }
// (one slot per API that ran in iteration i).
//
// Rules:
//   • If only ONE api ran → write columns directly (no prefix)
//     e.g. requestBody, responseBody, responseStatusCode
//   • If MULTIPLE apis ran → prefix each column with the API name
//     e.g. Create_User_requestBody, Get_User_responseBody
//   • testResult stays un-prefixed always (last-API result for
//     single-api; overall iteration result for multi-api is set
//     separately by the caller via results[i])
//
function flattenResponseData(apiDataMap) {
    if (!apiDataMap || typeof apiDataMap !== 'object') return {};

    const apiNames = Object.keys(apiDataMap);
    const flat = {};

    if (apiNames.length === 1) {
        // Single API — write without prefix
        const data = apiDataMap[apiNames[0]];
        Object.keys(data).forEach(col => {
            flat[col] = data[col];
        });
    } else {
        // Multiple APIs — prefix each column with API name
        apiNames.forEach(apiName => {
            const data = apiDataMap[apiName];
            const safePrefix = apiName.replace(/[^a-zA-Z0-9_]/g, '_');
            Object.keys(data).forEach(col => {
                flat[`${safePrefix}_${col}`] = data[col];
            });
        });
    }

    return flat;
}

// ======================================================
// UPDATE DATA FILE (CSV or XLSX)
// ======================================================

function updateDataFile(
    filePath,
    responseData,
    results,
    config
) {

    return new Promise(resolve => {

        // ── EXCEL ──────────────────────────────────────

        if (filePath.endsWith('.xlsx')) {

            const workbook =
                XLSX.readFile(filePath, { cellDates: true });

            const worksheetName =
                config.worksheet &&
                workbook.SheetNames.includes(config.worksheet)
                    ? config.worksheet
                    : workbook.SheetNames[0];

            const worksheet =
                workbook.Sheets[worksheetName];

            const rawData =
                XLSX.utils.sheet_to_json(
                    worksheet,
                    { defval: '', raw: true }
                );

            const jsonData = rawData.map(row => sanitizeRow(row));

            jsonData.forEach((row, i) => {

                row.testResult =
                    results[i] || '';

                if (responseData[i]) {
                    const flat = flattenResponseData(responseData[i]);
                    Object.keys(flat).forEach(key => {
                        row[key] = flat[key];
                    });
                }
            });

            // Coerce every cell value to a primitive xlsx can handle.
            // Objects, Arrays, null, undefined → empty string.
            // This prevents the "cell.length is not a function" /
            // "Cannot read properties of undefined (reading 'length')"
            // crash that xlsx throws when it encounters unexpected types.
            const safeData = jsonData.map(row => {
                const safe = {};
                Object.keys(row).forEach(key => {
                    const v = row[key];
                    if (v === null || v === undefined) {
                        safe[key] = '';
                    } else if (typeof v === 'object' && !(v instanceof Date)) {
                        safe[key] = JSON.stringify(v);
                    } else {
                        safe[key] = v;
                    }
                });
                return safe;
            });

            try {
                workbook.Sheets[worksheetName] =
                    XLSX.utils.json_to_sheet(safeData);

                XLSX.writeFile(workbook, filePath);

                console.log(`📘 Updated Excel: ${filePath}`);

            } catch (xlsxErr) {

                console.log(
                    `⚠️  Excel write failed: ${xlsxErr.message}`
                );
                console.log(
                    '   Test data file was NOT updated — ' +
                    'all other reports were still generated.'
                );
                return resolve();
            }

            // copy to reports
            if (copyTestDataToReports) {

                const dest =
                    path.join(
                        reportFolder,
                        path.basename(filePath)
                    );

                fs.copyFileSync(filePath, dest);

                console.log(
                    `📂 Test data copied to reports: ${path.basename(filePath)}`
                );

            } else {

                console.log(
                    'ℹ️  Test data copy skipped (copyTestDataToReports=false)'
                );
            }

            resolve();

        // ── CSV ────────────────────────────────────────

        } else {

            fs.readFile(filePath, 'utf8', (err, data) => {

                if (err) {
                    console.log(`❌ Unable to read: ${filePath}`);
                    return resolve();
                }

                const parsed =
                    Papa.parse(data, {
                        header: true,
                        skipEmptyLines: true
                    });

                parsed.data.forEach((row, i) => {

                    row.testResult =
                        results[i] || '';

                    if (responseData[i]) {
                        const flat = flattenResponseData(responseData[i]);
                        Object.keys(flat).forEach(key => {
                            row[key] = flat[key];
                        });
                    }
                });

                const updatedCsv =
                    Papa.unparse(parsed.data);

                fs.writeFileSync(filePath, updatedCsv);

                console.log(`📄 Updated CSV: ${filePath}`);

                // copy to reports
                if (copyTestDataToReports) {

                    const dest =
                        path.join(
                            reportFolder,
                            path.basename(filePath)
                        );

                    fs.copyFileSync(filePath, dest);

                    console.log(
                        `📂 Test data copied to reports: ${path.basename(filePath)}`
                    );

                } else {

                    console.log(
                        'ℹ️  Test data copy skipped (copyTestDataToReports=false)'
                    );
                }

                resolve();
            });
        }
    });
}

// ======================================================
// KICK OFF
// ======================================================

main().catch(err => {
    console.error(`\n❌ Fatal Error: ${err.message}`);
    process.exit(1);
});
