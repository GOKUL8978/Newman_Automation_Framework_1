// ======================================================
// scripts/swagger-validator.js
// ======================================================
//
// Loads OpenAPI / Swagger specs and validates Newman
// responses against them — like ReadyAPI's built-in
// Compliance Assertion.
//
// Supports:
//   • OpenAPI 3.x  (application/json responses)
//   • Swagger 2.x  (produces / definitions)
//   • JSON or YAML spec files
//
// Checks performed:
//   1. HTTP status code is declared in spec for that operation
//   2. Response Content-Type matches spec media type
//   3. Response body matches the JSON Schema for that status
//   4. Required properties present
//   5. Property types correct
//   6. String pattern / min / maxLength
//   7. Number minimum / maximum
//   8. Array minItems / maxItems
//   9. Enum values valid
//  10. No undeclared properties (additionalProperties:false)
//
// ======================================================

'use strict';

const fs   = require('fs');
const path = require('path');

let yaml;
try { yaml = require('js-yaml'); } catch (_) { yaml = null; }

// ── cache: avoid re-parsing the same file repeatedly ──
const _specCache = {};

// ======================================================
// PUBLIC: loadSpec
// ======================================================
/**
 * Load and parse a spec file from the ./swagger/ folder.
 * Returns the parsed spec object, or null on failure.
 * Results are cached — the same file is only read once.
 */
function loadSpec(specFileName) {

    if (!specFileName) return null;

    if (_specCache[specFileName]) {
        return _specCache[specFileName];
    }

    const specPath = path.resolve('./swagger', specFileName);

    if (!fs.existsSync(specPath)) {
        console.log(`⚠️  Swagger spec not found: ${specPath}`);
        return null;
    }

    try {

        const raw = fs.readFileSync(specPath, 'utf8');
        const spec = _parse(raw, specFileName);

        _specCache[specFileName] = spec;

        console.log(
            `📋 Swagger spec loaded: ${spec.info?.title || specFileName} ` +
            `v${spec.info?.version || '?'} ` +
            `(${_isOas3(spec) ? 'OpenAPI 3.x' : 'Swagger 2.x'})`
        );

        return spec;

    } catch (err) {
        console.log(`⚠️  Swagger spec parse error [${specFileName}]: ${err.message}`);
        return null;
    }
}

// ======================================================
// PUBLIC: validateResponse
// ======================================================
/**
 * Validates a Newman request/response pair against a spec.
 *
 * @param {object} spec           — parsed spec from loadSpec()
 * @param {string} method         — HTTP method ('GET', 'POST', …)
 * @param {string} url            — full request URL
 * @param {number} statusCode     — actual HTTP status code
 * @param {string} responseBody   — raw response body string
 * @param {object} responseHeaders — key/value response headers
 *
 * @returns {{ passed: boolean, violations: Array }}
 */
function validateResponse(spec, method, url, statusCode, responseBody, responseHeaders) {

    const result = { passed: true, violations: [] };

    if (!spec) return result;

    // 1. resolve the operation from the spec
    const operation = _resolveOperation(spec, method, url);

    if (!operation) {
        result.violations.push({
            code:    'UNDOCUMENTED_ENDPOINT',
            message: `No spec definition for ${method.toUpperCase()} ${_extractPath(spec, url)}`
        });
        result.passed = false;
        return result;
    }

    // 2. status code declared?
    const statusKey  = String(statusCode);
    const responses  = operation.responses || {};
    const statusDef  = responses[statusKey] || responses['default'];

    if (!statusDef) {
        result.violations.push({
            code:    'UNDECLARED_STATUS_CODE',
            message: `Status ${statusCode} not in spec. Declared: [${Object.keys(responses).join(', ')}]`
        });
        result.passed = false;
    }

    // 3. Content-Type matches?
    const actualCT     = ((responseHeaders['content-type'] || responseHeaders['Content-Type'] || '')).split(';')[0].trim();
    const declaredMTs  = _getDeclaredMediaTypes(spec, operation, statusKey);

    if (actualCT && declaredMTs.length > 0 && !declaredMTs.some(mt => actualCT.includes(mt))) {
        result.violations.push({
            code:    'CONTENT_TYPE_MISMATCH',
            message: `Content-Type '${actualCT}' not in spec: [${declaredMTs.join(', ')}]`
        });
        result.passed = false;
    }

    // 4. validate JSON body schema
    if (!actualCT || actualCT.includes('application/json') || actualCT === '') {

        let parsed = null;
        try { parsed = JSON.parse(responseBody); } catch (_) {}

        if (parsed !== null) {

            const schema = _resolveResponseSchema(spec, operation, statusKey, actualCT);

            if (schema) {
                _validateSchema(parsed, schema, spec, '$').forEach(v => {
                    result.violations.push(v);
                    result.passed = false;
                });
            }
        }
    }

    return result;
}

// ======================================================
// INTERNALS
// ======================================================

function _parse(raw, filename) {
    if (raw.trim().startsWith('{')) return JSON.parse(raw);
    if (yaml) return yaml.load(raw);
    throw new Error(`YAML spec '${filename}' requires js-yaml. Run: npm install js-yaml`);
}

function _isOas3(spec) {
    return !!(spec.openapi && spec.openapi.startsWith('3'));
}

function _getBasePath(spec) {
    if (_isOas3(spec)) {
        const s = (spec.servers || [])[0];
        if (!s) return '';
        try { return new URL(s.url).pathname.replace(/\/$/, ''); } catch (_) { return s.url.replace(/\/$/, ''); }
    }
    return (spec.basePath || '').replace(/\/$/, '');
}

function _extractPath(spec, url) {
    try {
        const u  = new URL(url);
        const bp = _getBasePath(spec);
        const p  = u.pathname;
        return bp && p.startsWith(bp) ? (p.slice(bp.length) || '/') : p;
    } catch (_) {
        return url.split('?')[0].split('#')[0];
    }
}

function _pathMatches(specPath, actual) {
    const pat =
        '^' +
        specPath
            .replace(/[.+^${}()|[\]\\]/g, c => (c === '{' || c === '}') ? c : '\\' + c)
            .replace(/\{[^}]+\}/g, '[^/]+') +
        '\\/?$';
    return new RegExp(pat).test(actual);
}

function _resolveOperation(spec, method, url) {
    const actual = _extractPath(spec, url);
    const m = method.toLowerCase();
    for (const sp of Object.keys(spec.paths || {})) {
        if (_pathMatches(sp, actual)) {
            const op = (spec.paths[sp] || {})[m];
            if (op) return op;
        }
    }
    return null;
}

function _getDeclaredMediaTypes(spec, operation, statusKey) {
    if (_isOas3(spec)) {
        const resp = (operation.responses || {})[statusKey] || (operation.responses || {})['default'];
        return resp ? Object.keys(resp.content || {}) : [];
    }
    return operation.produces || spec.produces || ['application/json'];
}

function _resolveResponseSchema(spec, operation, statusKey, contentType) {
    const resp = (operation.responses || {})[statusKey] || (operation.responses || {})['default'];
    if (!resp) return null;
    if (_isOas3(spec)) {
        const content = resp.content || {};
        const key = content[contentType]
            ? contentType
            : Object.keys(content).find(k => contentType.includes(k.replace('*', '')));
        const mo = key ? content[key] : null;
        return mo && mo.schema ? _deref(mo.schema, spec) : null;
    }
    return resp.schema ? _deref(resp.schema, spec) : null;
}

function _deref(schema, spec, visited = new Set()) {
    if (!schema || typeof schema !== 'object') return schema;
    if (schema.$ref) {
        if (visited.has(schema.$ref)) return { type: 'object', 'x-circular': true };
        const v2 = new Set(visited).add(schema.$ref);
        const parts = schema.$ref.slice(2).split('/');
        let node = spec;
        for (const p of parts) { if (node == null) return null; node = node[p]; }
        return node ? _deref(node, spec, v2) : null;
    }
    const r = { ...schema };
    if (r.properties) r.properties = Object.fromEntries(Object.entries(r.properties).map(([k, v]) => [k, _deref(v, spec, visited)]));
    if (r.items) r.items = _deref(r.items, spec, visited);
    ['allOf', 'oneOf', 'anyOf'].forEach(k => { if (r[k]) r[k] = r[k].map(s => _deref(s, spec, visited)); });
    return r;
}

function _validateSchema(value, schema, spec, jp) {
    if (!schema) return [];
    const v = [];

    if (schema.allOf) { schema.allOf.forEach(s => _validateSchema(value, s, spec, jp).forEach(e => v.push(e))); return v; }
    if (schema.oneOf) {
        const ok = schema.oneOf.filter(s => _validateSchema(value, s, spec, jp).length === 0);
        if (ok.length !== 1) v.push({ code: 'SCHEMA_ONEOF_MISMATCH', message: `${jp}: must satisfy exactly one schema (matched ${ok.length})`, path: jp });
        return v;
    }
    if (schema.anyOf) {
        const ok = schema.anyOf.filter(s => _validateSchema(value, s, spec, jp).length === 0);
        if (ok.length === 0) v.push({ code: 'SCHEMA_ANYOF_MISMATCH', message: `${jp}: does not match any declared schema`, path: jp });
        return v;
    }

    if (schema.type && !schema['x-circular']) {
        const tv = _checkType(value, schema.type, jp);
        if (tv) { v.push(tv); return v; }
    }

    if (value === null || value === undefined) return v;

    if (schema.enum && !schema.enum.includes(value)) {
        v.push({ code: 'SCHEMA_ENUM_MISMATCH', message: `${jp}: '${value}' not in enum [${schema.enum.join(', ')}]`, path: jp });
    }

    if (schema.type === 'object' || schema.properties) {
        (schema.required || []).forEach(req => {
            if (value[req] === undefined || value[req] === null)
                v.push({ code: 'MISSING_REQUIRED_FIELD', message: `${jp}.${req}: required field missing`, path: `${jp}.${req}` });
        });
        if (schema.properties) {
            Object.entries(schema.properties).forEach(([k, ps]) => {
                if (value[k] !== undefined) _validateSchema(value[k], ps, spec, `${jp}.${k}`).forEach(e => v.push(e));
            });
        }
        if (schema.additionalProperties === false && schema.properties) {
            const dec = new Set(Object.keys(schema.properties));
            Object.keys(value).forEach(k => {
                if (!dec.has(k)) v.push({ code: 'ADDITIONAL_PROPERTY', message: `${jp}.${k}: not in spec (additionalProperties:false)`, path: `${jp}.${k}` });
            });
        }
    }

    if (schema.type === 'array' && schema.items && Array.isArray(value)) {
        value.forEach((item, i) => _validateSchema(item, schema.items, spec, `${jp}[${i}]`).forEach(e => v.push(e)));
        if (schema.minItems !== undefined && value.length < schema.minItems) v.push({ code: 'ARRAY_MIN_ITEMS', message: `${jp}: ${value.length} items < minItems ${schema.minItems}`, path: jp });
        if (schema.maxItems !== undefined && value.length > schema.maxItems) v.push({ code: 'ARRAY_MAX_ITEMS', message: `${jp}: ${value.length} items > maxItems ${schema.maxItems}`, path: jp });
    }

    if (schema.type === 'string' && typeof value === 'string') {
        if (schema.minLength !== undefined && value.length < schema.minLength) v.push({ code: 'STRING_MIN_LENGTH', message: `${jp}: length ${value.length} < minLength ${schema.minLength}`, path: jp });
        if (schema.maxLength !== undefined && value.length > schema.maxLength) v.push({ code: 'STRING_MAX_LENGTH', message: `${jp}: length ${value.length} > maxLength ${schema.maxLength}`, path: jp });
        if (schema.pattern && !new RegExp(schema.pattern).test(value)) v.push({ code: 'STRING_PATTERN_MISMATCH', message: `${jp}: '${value}' does not match pattern '${schema.pattern}'`, path: jp });
    }

    if ((schema.type === 'number' || schema.type === 'integer') && typeof value === 'number') {
        if (schema.minimum !== undefined && (schema.exclusiveMinimum ? value <= schema.minimum : value < schema.minimum)) v.push({ code: 'NUMBER_MINIMUM', message: `${jp}: ${value} < minimum ${schema.minimum}`, path: jp });
        if (schema.maximum !== undefined && (schema.exclusiveMaximum ? value >= schema.maximum : value > schema.maximum)) v.push({ code: 'NUMBER_MAXIMUM', message: `${jp}: ${value} > maximum ${schema.maximum}`, path: jp });
    }

    return v;
}

function _checkType(value, expectedType, jp) {
    const types  = Array.isArray(expectedType) ? expectedType : [expectedType];
    if (value === null && types.includes('null')) return null;
    if (value === null) return null;
    const actual = Array.isArray(value) ? 'array' : typeof value;
    const ok = types.some(t => {
        switch (t) {
            case 'integer': return Number.isInteger(value);
            case 'number':  return typeof value === 'number';
            case 'string':  return typeof value === 'string';
            case 'boolean': return typeof value === 'boolean';
            case 'array':   return Array.isArray(value);
            case 'object':  return typeof value === 'object' && !Array.isArray(value) && value !== null;
            default:        return true;
        }
    });
    return ok ? null : { code: 'TYPE_MISMATCH', message: `${jp}: expected '${types.join('|')}', got '${actual}'`, path: jp };
}

module.exports = { loadSpec, validateResponse };
